﻿using SHDocVw;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{ 
    public partial class türk_havayolları : Form
    {
       
        public türk_havayolları()
        {
            InitializeComponent();
        }
 
        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void türk_havayolları_Load(object sender, EventArgs e)
        {
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            webBrowser1 . Navigate("https://www.turkishairlines.com/?gad_source=1&gclid=CjwKCAjw1920BhA3EiwAJT3lSUWBpcJtZYzEI3qv-2sKQbFfSMMTBxmsABm852lWL6nzJWAVfoSj0hoC0OQQAvD_BwE");

        }
    }
}
